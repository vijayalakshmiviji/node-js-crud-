use demo;
ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'Cybomb@123';
flush privileges;