create database newdb;
create table mytable(id int , name varchar(10), email varchar(200), no bigint(10));
insert into mytable values(1,"viji","viji@123",9344263137);
use newdb;
select * from mytable;