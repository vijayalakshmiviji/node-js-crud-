 create database djit_trading_db;
 use djit_trading_db;
 ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'cybomb';
FLUSH PRIVILEGES;
 CREATE TABLE user(  
    id int NOT NULL AUTO_INCREMENT,  
    name varchar(60) NOT NULL,  
    email varchar(60) NOT NULL,  
    password varchar(60) NOT NULL,   
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    agreed_terms_and_conditions BOOLEAN NOT NULL default 0,
    PRIMARY KEY (id)  
);
 CREATE TABLE refresh_token(  
    id int NOT NULL AUTO_INCREMENT,  
    token varchar(5000) NOT NULL, 
    user_id int NOT NULL,    
    PRIMARY KEY (id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    foreign key (user_id) REFERENCES user(id)
);  